Website Name - Forty-Five Restaurant
Link - https://www.barfortyfive.ch/